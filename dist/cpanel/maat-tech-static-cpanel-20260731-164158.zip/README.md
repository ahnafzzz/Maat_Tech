# MECHARM Prototype

This workspace has been organized into a deployable static front-end prototype for a premium lighting storefront and its supporting admin/customer experiences. It is now positioned as the starting point for a full Laravel implementation with Blade, Filament, API endpoints, payments, shipping, search, and admin management.

## Included files
- [index.html](index.html) – landing page with links to all experiences
- [mech-lamp-storefront.html](mech-lamp-storefront.html) – storefront experience
- [customer-dashboard.html](customer-dashboard.html) – customer account dashboard
- [lead-admin-panel.html](lead-admin-panel.html) – lead admin control panel
- [admin-login.html](admin-login.html) – admin sign-in view
- [theme-toggle.css](theme-toggle.css) – shared light/dark theme styles
- [theme-toggle.js](theme-toggle.js) – shared dark-default theme toggle logic
- [USER_GUIDE.md](USER_GUIDE.md) – full usage and deployment guide

## Run locally
From this folder, run:

```bash
npm start
```

Then open http://localhost:3000.

## Theme behavior
- Dark mode is the default.
- A floating toggle button is available on all primary pages.
- Theme preference is saved in browser localStorage.

## Prepare for cPanel upload (without deploying yet)
1. Build a static upload archive:
	```bash
	npm run cpanel:package
	```
2. The zip file will be generated in `dist/cpanel/`.
3. Use [deployment/CPANEL_PREP_CHECKLIST.md](deployment/CPANEL_PREP_CHECKLIST.md) when you are ready to upload.

## Deploy to static hosts
This project is compatible with:
- Netlify
- Vercel
- GitHub Pages
- Any static file host

For Netlify and Vercel, simply point the publish directory to the project root.
